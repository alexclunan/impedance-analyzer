//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Sep  2 12:09:07 2026
//Host        : DESKTOP-F1EP304 running 64-bit major release  (build 9200)
//Command     : generate_target modulator_chain.bd
//Design      : modulator_chain
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "modulator_chain,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=modulator_chain,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=12,numReposBlks=12,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=0,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}" *) (* HW_HANDOFF = "modulator_chain.hwdef" *) 
module modulator_chain
   (S_AXIS_FIR_CONFIG_0_tdata,
    S_AXIS_FIR_CONFIG_0_tready,
    S_AXIS_FIR_CONFIG_0_tvalid,
    S_AXIS_FIR_RELOAD_0_tdata,
    S_AXIS_FIR_RELOAD_0_tlast,
    S_AXIS_FIR_RELOAD_0_tready,
    S_AXIS_FIR_RELOAD_0_tvalid,
    adc_input,
    clk,
    dds_cos_out,
    dds_sin_out,
    dds_valid,
    event_pinc_invalid_0,
    fcw_tdata,
    fcw_tvalid,
    r_phase_out_tdata,
    r_phase_out_tvalid,
    resetn,
    s_axis_config_CIC_tdata_0,
    s_axis_config_CIC_tvalid_0);
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_CONFIG_0 TDATA" *) (* X_INTERFACE_MODE = "Slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXIS_FIR_CONFIG_0, CLK_DOMAIN modulator_chain_clk, FREQ_HZ 200000000, HAS_TKEEP 0, HAS_TLAST 0, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.0, TDATA_NUM_BYTES 1, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) input [7:0]S_AXIS_FIR_CONFIG_0_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_CONFIG_0 TREADY" *) output S_AXIS_FIR_CONFIG_0_tready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_CONFIG_0 TVALID" *) input S_AXIS_FIR_CONFIG_0_tvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_RELOAD_0 TDATA" *) (* X_INTERFACE_MODE = "Slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME S_AXIS_FIR_RELOAD_0, CLK_DOMAIN modulator_chain_clk, FREQ_HZ 200000000, HAS_TKEEP 0, HAS_TLAST 1, HAS_TREADY 1, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.0, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) input [15:0]S_AXIS_FIR_RELOAD_0_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_RELOAD_0 TLAST" *) input S_AXIS_FIR_RELOAD_0_tlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_RELOAD_0 TREADY" *) output S_AXIS_FIR_RELOAD_0_tready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 S_AXIS_FIR_RELOAD_0 TVALID" *) input S_AXIS_FIR_RELOAD_0_tvalid;
  input [15:0]adc_input;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK, ASSOCIATED_BUSIF fcw:r_phase_out:S_AXIS_FIR_RELOAD_0:S_AXIS_FIR_CONFIG_0, ASSOCIATED_RESET resetn, CLK_DOMAIN modulator_chain_clk, FREQ_HZ 200000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input clk;
  output [15:0]dds_cos_out;
  output [15:0]dds_sin_out;
  output dds_valid;
  (* X_INTERFACE_INFO = "xilinx.com:signal:interrupt:1.0 INTR.EVENT_PINC_INVALID_0 INTERRUPT" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME INTR.EVENT_PINC_INVALID_0, PortWidth 1, SENSITIVITY EDGE_RISING" *) output event_pinc_invalid_0;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 fcw TDATA" *) (* X_INTERFACE_MODE = "Slave" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME fcw, CLK_DOMAIN modulator_chain_clk, FREQ_HZ 200000000, HAS_TKEEP 0, HAS_TLAST 0, HAS_TREADY 0, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA undef, PHASE 0.0, TDATA_NUM_BYTES 2, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) input [15:0]fcw_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 fcw TVALID" *) input fcw_tvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 r_phase_out TDATA" *) (* X_INTERFACE_MODE = "Master" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME r_phase_out, CLK_DOMAIN modulator_chain_clk, FREQ_HZ 200000000, HAS_TKEEP 0, HAS_TLAST 0, HAS_TREADY 0, HAS_TSTRB 0, INSERT_VIP 0, LAYERED_METADATA xilinx.com:interface:datatypes:1.0 {TDATA {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type automatic dependency {} format long minimum {} maximum {}} value 64} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} struct {field_real {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value real} enabled {attribs {resolve_type generated dependency polar_mag_enabled format bool minimum {} maximum {}} value true} datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type generated dependency polar_mag_width format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} real {fixed {fractwidth {attribs {resolve_type generated dependency polar_mag_fractwidth format long minimum {} maximum {}} value 30} signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}} field_phase {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value phase} enabled {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true} datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type generated dependency polar_phase_width format long minimum {} maximum {}} value 32} bitoffset {attribs {resolve_type generated dependency polar_phase_offset format long minimum {} maximum {}} value 32} real {fixed {fractwidth {attribs {resolve_type generated dependency polar_phase_fractwidth format long minimum {} maximum {}} value 29} signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value true}}}}}}}} TDATA_WIDTH 64 TUSER {datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type automatic dependency {} format long minimum {} maximum {}} value 0} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} struct {field_cartesian_tuser {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value cartesian_tuser} enabled {attribs {resolve_type generated dependency cart_enabled format bool minimum {} maximum {}} value false} datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type generated dependency cart_width format long minimum {} maximum {}} value 0} bitoffset {attribs {resolve_type immediate dependency {} format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}} field_phase_tuser {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value phase_tuser} enabled {attribs {resolve_type generated dependency phase_enabled format bool minimum {} maximum {}} value false} datatype {name {attribs {resolve_type immediate dependency {} format string minimum {} maximum {}} value {}} bitwidth {attribs {resolve_type generated dependency phase_width format long minimum {} maximum {}} value 0} bitoffset {attribs {resolve_type generated dependency phase_offset format long minimum {} maximum {}} value 0} integer {signed {attribs {resolve_type immediate dependency {} format bool minimum {} maximum {}} value false}}}}}}} TUSER_WIDTH 0}, PHASE 0.0, TDATA_NUM_BYTES 8, TDEST_WIDTH 0, TID_WIDTH 0, TUSER_WIDTH 0" *) output [63:0]r_phase_out_tdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:axis:1.0 r_phase_out TVALID" *) output r_phase_out_tvalid;
  input resetn;
  input [15:0]s_axis_config_CIC_tdata_0;
  input s_axis_config_CIC_tvalid_0;

  wire [47:0]CIC_Filter_I1_m_axis_data_tdata;
  wire CIC_Filter_I1_m_axis_data_tvalid;
  wire [47:0]CIC_Filter_I_m_axis_data_tdata;
  wire CIC_Filter_I_m_axis_data_tvalid;
  wire [0:0]CIC_valid_Res;
  wire [95:0]FIR_input_dout;
  wire [7:0]S_AXIS_FIR_CONFIG_0_tdata;
  wire S_AXIS_FIR_CONFIG_0_tready;
  wire S_AXIS_FIR_CONFIG_0_tvalid;
  wire [15:0]S_AXIS_FIR_RELOAD_0_tdata;
  wire S_AXIS_FIR_RELOAD_0_tlast;
  wire S_AXIS_FIR_RELOAD_0_tready;
  wire S_AXIS_FIR_RELOAD_0_tvalid;
  wire [15:0]adc_input;
  wire clk;
  wire [31:0]dds_compiler_0_m_axis_data_tdata;
  wire [15:0]dds_cos_out;
  wire [15:0]dds_sin_out;
  wire dds_valid;
  wire event_pinc_invalid_0;
  wire [15:0]fcw_tdata;
  wire fcw_tvalid;
  wire [95:0]fir_compiler_0_M_AXIS_DATA_TDATA;
  wire fir_compiler_0_M_AXIS_DATA_TVALID;
  wire [0:0]ilconstant_0_dout;
  wire [31:0]mixer_I_P;
  wire [31:0]mixer_Q_P;
  wire [63:0]r_phase_out_tdata;
  wire r_phase_out_tvalid;
  wire resetn;
  wire [15:0]s_axis_config_CIC_tdata_0;
  wire s_axis_config_CIC_tvalid_0;

  modulator_chain_cic_compiler_0_0 CIC_Filter_I
       (.aclk(clk),
        .aresetn(resetn),
        .m_axis_data_tdata(CIC_Filter_I_m_axis_data_tdata),
        .m_axis_data_tvalid(CIC_Filter_I_m_axis_data_tvalid),
        .s_axis_config_tdata(s_axis_config_CIC_tdata_0),
        .s_axis_config_tvalid(s_axis_config_CIC_tvalid_0),
        .s_axis_data_tdata(mixer_I_P),
        .s_axis_data_tvalid(ilconstant_0_dout));
  modulator_chain_CIC_Filter_I_0 CIC_Filter_Q
       (.aclk(clk),
        .aresetn(resetn),
        .m_axis_data_tdata(CIC_Filter_I1_m_axis_data_tdata),
        .m_axis_data_tvalid(CIC_Filter_I1_m_axis_data_tvalid),
        .s_axis_config_tdata(s_axis_config_CIC_tdata_0),
        .s_axis_config_tvalid(s_axis_config_CIC_tvalid_0),
        .s_axis_data_tdata(mixer_Q_P),
        .s_axis_data_tvalid(ilconstant_0_dout));
  assign CIC_valid_Res = CIC_Filter_I_m_axis_data_tvalid & CIC_Filter_I1_m_axis_data_tvalid;
  modulator_chain_fir_compiler_0_0 FIR_Filter
       (.aclk(clk),
        .m_axis_data_tdata(fir_compiler_0_M_AXIS_DATA_TDATA),
        .m_axis_data_tvalid(fir_compiler_0_M_AXIS_DATA_TVALID),
        .s_axis_config_tdata(S_AXIS_FIR_CONFIG_0_tdata),
        .s_axis_config_tready(S_AXIS_FIR_CONFIG_0_tready),
        .s_axis_config_tvalid(S_AXIS_FIR_CONFIG_0_tvalid),
        .s_axis_data_tdata(FIR_input_dout),
        .s_axis_data_tvalid(CIC_valid_Res),
        .s_axis_reload_tdata(S_AXIS_FIR_RELOAD_0_tdata),
        .s_axis_reload_tlast(S_AXIS_FIR_RELOAD_0_tlast),
        .s_axis_reload_tready(S_AXIS_FIR_RELOAD_0_tready),
        .s_axis_reload_tvalid(S_AXIS_FIR_RELOAD_0_tvalid));
  assign FIR_input_dout = {CIC_Filter_I1_m_axis_data_tdata, CIC_Filter_I_m_axis_data_tdata};
  assign dds_cos_out = dds_compiler_0_m_axis_data_tdata[15:0];
  assign dds_sin_out = dds_compiler_0_m_axis_data_tdata[31:16];
  assign ilconstant_0_dout = 1'h1;
  modulator_chain_cordic_0_0 mag_phase_calc
       (.aclk(clk),
        .m_axis_dout_tdata(r_phase_out_tdata),
        .m_axis_dout_tvalid(r_phase_out_tvalid),
        .s_axis_cartesian_tdata(fir_compiler_0_M_AXIS_DATA_TDATA),
        .s_axis_cartesian_tvalid(fir_compiler_0_M_AXIS_DATA_TVALID));
  modulator_chain_mult_gen_0_0 mixer_I
       (.A(adc_input),
        .B(dds_cos_out),
        .CLK(clk),
        .P(mixer_I_P));
  modulator_chain_mult_gen_0_1 mixer_Q
       (.A(adc_input),
        .B(dds_sin_out),
        .CLK(clk),
        .P(mixer_Q_P));
  modulator_chain_dds_compiler_0_0 modulator
       (.aclk(clk),
        .event_pinc_invalid(event_pinc_invalid_0),
        .m_axis_data_tdata(dds_compiler_0_m_axis_data_tdata),
        .m_axis_data_tvalid(dds_valid),
        .s_axis_config_tdata(fcw_tdata),
        .s_axis_config_tvalid(fcw_tvalid));
endmodule
