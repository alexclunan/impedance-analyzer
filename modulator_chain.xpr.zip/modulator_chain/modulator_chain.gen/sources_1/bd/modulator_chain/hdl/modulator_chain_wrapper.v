//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
//Date        : Wed Sep  2 12:09:07 2026
//Host        : DESKTOP-F1EP304 running 64-bit major release  (build 9200)
//Command     : generate_target modulator_chain_wrapper.bd
//Design      : modulator_chain_wrapper
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

module modulator_chain_wrapper
   (S_AXIS_FIR_CONFIG_0_tdata,
    S_AXIS_FIR_CONFIG_0_tready,
    S_AXIS_FIR_CONFIG_0_tvalid,
    S_AXIS_FIR_RELOAD_0_tdata,
    S_AXIS_FIR_RELOAD_0_tlast,
    S_AXIS_FIR_RELOAD_0_tready,
    S_AXIS_FIR_RELOAD_0_tvalid,
    adc_input,
    clk,
    dds_cos_out,
    dds_sin_out,
    dds_valid,
    event_pinc_invalid_0,
    fcw_tdata,
    fcw_tvalid,
    r_phase_out_tdata,
    r_phase_out_tvalid,
    resetn,
    s_axis_config_CIC_tdata_0,
    s_axis_config_CIC_tvalid_0);
  input [7:0]S_AXIS_FIR_CONFIG_0_tdata;
  output S_AXIS_FIR_CONFIG_0_tready;
  input S_AXIS_FIR_CONFIG_0_tvalid;
  input [15:0]S_AXIS_FIR_RELOAD_0_tdata;
  input S_AXIS_FIR_RELOAD_0_tlast;
  output S_AXIS_FIR_RELOAD_0_tready;
  input S_AXIS_FIR_RELOAD_0_tvalid;
  input [15:0]adc_input;
  input clk;
  output [15:0]dds_cos_out;
  output [15:0]dds_sin_out;
  output dds_valid;
  output event_pinc_invalid_0;
  input [15:0]fcw_tdata;
  input fcw_tvalid;
  output [63:0]r_phase_out_tdata;
  output r_phase_out_tvalid;
  input resetn;
  input [15:0]s_axis_config_CIC_tdata_0;
  input s_axis_config_CIC_tvalid_0;

  wire [7:0]S_AXIS_FIR_CONFIG_0_tdata;
  wire S_AXIS_FIR_CONFIG_0_tready;
  wire S_AXIS_FIR_CONFIG_0_tvalid;
  wire [15:0]S_AXIS_FIR_RELOAD_0_tdata;
  wire S_AXIS_FIR_RELOAD_0_tlast;
  wire S_AXIS_FIR_RELOAD_0_tready;
  wire S_AXIS_FIR_RELOAD_0_tvalid;
  wire [15:0]adc_input;
  wire clk;
  wire [15:0]dds_cos_out;
  wire [15:0]dds_sin_out;
  wire dds_valid;
  wire event_pinc_invalid_0;
  wire [15:0]fcw_tdata;
  wire fcw_tvalid;
  wire [63:0]r_phase_out_tdata;
  wire r_phase_out_tvalid;
  wire resetn;
  wire [15:0]s_axis_config_CIC_tdata_0;
  wire s_axis_config_CIC_tvalid_0;

  modulator_chain modulator_chain_i
       (.S_AXIS_FIR_CONFIG_0_tdata(S_AXIS_FIR_CONFIG_0_tdata),
        .S_AXIS_FIR_CONFIG_0_tready(S_AXIS_FIR_CONFIG_0_tready),
        .S_AXIS_FIR_CONFIG_0_tvalid(S_AXIS_FIR_CONFIG_0_tvalid),
        .S_AXIS_FIR_RELOAD_0_tdata(S_AXIS_FIR_RELOAD_0_tdata),
        .S_AXIS_FIR_RELOAD_0_tlast(S_AXIS_FIR_RELOAD_0_tlast),
        .S_AXIS_FIR_RELOAD_0_tready(S_AXIS_FIR_RELOAD_0_tready),
        .S_AXIS_FIR_RELOAD_0_tvalid(S_AXIS_FIR_RELOAD_0_tvalid),
        .adc_input(adc_input),
        .clk(clk),
        .dds_cos_out(dds_cos_out),
        .dds_sin_out(dds_sin_out),
        .dds_valid(dds_valid),
        .event_pinc_invalid_0(event_pinc_invalid_0),
        .fcw_tdata(fcw_tdata),
        .fcw_tvalid(fcw_tvalid),
        .r_phase_out_tdata(r_phase_out_tdata),
        .r_phase_out_tvalid(r_phase_out_tvalid),
        .resetn(resetn),
        .s_axis_config_CIC_tdata_0(s_axis_config_CIC_tdata_0),
        .s_axis_config_CIC_tvalid_0(s_axis_config_CIC_tvalid_0));
endmodule
