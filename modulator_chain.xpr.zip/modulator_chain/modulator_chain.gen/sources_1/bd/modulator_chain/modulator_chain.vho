-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
-- -------------------------------------------------------------------------------
-- This file contains confidential and proprietary information
-- of AMD and is protected under U.S. and international copyright
-- and other intellectual property laws.
--
-- DISCLAIMER
-- This disclaimer is not a license and does not grant any
-- rights to the materials distributed herewith. Except as
-- otherwise provided in a valid license issued to you by
-- AMD, and to the maximum extent permitted by applicable
-- law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
-- WITH ALL FAULTS, AND AMD HEREBY DISCLAIMS ALL WARRANTIES
-- AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
-- BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
-- INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
-- (2) AMD shall not be liable (whether in contract or tort,
-- including negligence, or under any other theory of
-- liability) for any loss or damage of any kind or nature
-- related to, arising under or in connection with these
-- materials, including for any direct, or any indirect,
-- special, incidental, or consequential loss or damage
-- (including loss of data, profits, goodwill, or any type of
-- loss or damage suffered as a result of any action brought
-- by a third party) even if such damage or loss was
-- reasonably foreseeable or AMD had been advised of the
-- possibility of the same.
--
-- CRITICAL APPLICATIONS
-- AMD products are not designed or intended to be fail-
-- safe, or for use in any application requiring fail-safe
-- performance, such as life-support or safety devices or
-- systems, Class III medical devices, nuclear facilities,
-- applications related to the deployment of airbags, or any
-- other applications that could lead to death, personal
-- injury, or severe property or environmental damage
-- (individually and collectively, "Critical
-- Applications"). Customer assumes the sole risk and
-- liability of any use of AMD products in Critical
-- Applications, subject only to applicable laws and
-- regulations governing limitations on product liability.
--
-- THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
-- PART OF THIS FILE AT ALL TIMES.
--
-- DO NOT MODIFY THIS FILE.

-- MODULE VLNV: amd.com:blockdesign:modulator_chain:1.0

-- The following code must appear in the VHDL architecture header.

-- COMP_TAG     ------ Begin cut for COMPONENT Declaration ------
COMPONENT modulator_chain
  PORT (
    fcw_tdata : IN STD_LOGIC_VECTOR(15 DOWNTO 0);
    fcw_tvalid : IN STD_LOGIC;
    r_phase_out_tdata : OUT STD_LOGIC_VECTOR(63 DOWNTO 0);
    r_phase_out_tvalid : OUT STD_LOGIC;
    adc_input : IN STD_LOGIC_VECTOR(15 DOWNTO 0);
    clk : IN STD_LOGIC;
    resetn : IN STD_LOGIC;
    event_pinc_invalid_0 : OUT STD_LOGIC;
    dds_valid : OUT STD_LOGIC;
    dds_sin_out : OUT STD_LOGIC_VECTOR(15 DOWNTO 0);
    dds_cos_out : OUT STD_LOGIC_VECTOR(15 DOWNTO 0);
    s_axis_config_CIC_tdata_0 : IN STD_LOGIC_VECTOR(15 DOWNTO 0);
    s_axis_config_CIC_tvalid_0 : IN STD_LOGIC;
    S_AXIS_FIR_RELOAD_0_tdata : IN STD_LOGIC_VECTOR(15 DOWNTO 0);
    S_AXIS_FIR_RELOAD_0_tlast : IN STD_LOGIC;
    S_AXIS_FIR_RELOAD_0_tready : OUT STD_LOGIC;
    S_AXIS_FIR_RELOAD_0_tvalid : IN STD_LOGIC;
    S_AXIS_FIR_CONFIG_0_tdata : IN STD_LOGIC_VECTOR(7 DOWNTO 0);
    S_AXIS_FIR_CONFIG_0_tready : OUT STD_LOGIC;
    S_AXIS_FIR_CONFIG_0_tvalid : IN STD_LOGIC
  );
END COMPONENT;
-- COMP_TAG_END ------  End cut for COMPONENT Declaration  ------

-- The following code must appear in the VHDL architecture
-- body. Substitute your own instance name and net names.

-- INST_TAG     ------ Begin cut for INSTANTIATION Template ------
your_instance_name : modulator_chain
  PORT MAP (
    fcw_tdata => fcw_tdata,
    fcw_tvalid => fcw_tvalid,
    r_phase_out_tdata => r_phase_out_tdata,
    r_phase_out_tvalid => r_phase_out_tvalid,
    adc_input => adc_input,
    clk => clk,
    resetn => resetn,
    event_pinc_invalid_0 => event_pinc_invalid_0,
    dds_valid => dds_valid,
    dds_sin_out => dds_sin_out,
    dds_cos_out => dds_cos_out,
    s_axis_config_CIC_tdata_0 => s_axis_config_CIC_tdata_0,
    s_axis_config_CIC_tvalid_0 => s_axis_config_CIC_tvalid_0,
    S_AXIS_FIR_RELOAD_0_tdata => S_AXIS_FIR_RELOAD_0_tdata,
    S_AXIS_FIR_RELOAD_0_tlast => S_AXIS_FIR_RELOAD_0_tlast,
    S_AXIS_FIR_RELOAD_0_tready => S_AXIS_FIR_RELOAD_0_tready,
    S_AXIS_FIR_RELOAD_0_tvalid => S_AXIS_FIR_RELOAD_0_tvalid,
    S_AXIS_FIR_CONFIG_0_tdata => S_AXIS_FIR_CONFIG_0_tdata,
    S_AXIS_FIR_CONFIG_0_tready => S_AXIS_FIR_CONFIG_0_tready,
    S_AXIS_FIR_CONFIG_0_tvalid => S_AXIS_FIR_CONFIG_0_tvalid
  );
-- INST_TAG_END ------  End cut for INSTANTIATION Template  ------

-- You must compile the wrapper file modulator_chain.vhd when simulating
-- the module, modulator_chain. When compiling the wrapper file, be sure to
-- reference the VHDL simulation library.
